<details>
<summary>服务器成立一周年纪念日</summary>
在2021年的今天，甜瓜の养老服务器成立了

2022.10.29-2022.10.30
</details>