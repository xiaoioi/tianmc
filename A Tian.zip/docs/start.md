# 开始游玩

## 手机

1. 打开MC基岩版
2. 点击游戏 服务器 添加服务器
3. 输入服务器的地址:
4. 开始游玩吧


## 电脑
### UWP
1. 打开MC基岩版
2. 点击游戏 服务器 添加服务器
3. 输入服务器的地址
4. 开始游玩吧

### JAVA
安装教程:【[保姆级HMCL启动器教程，稍微懂点电脑就能看懂！-哔哩哔哩](https://b23.tv/ndCCKqG)】 

1. 打开MCJAVA版
2. 点击多人游戏 添加服务器
3. 输入服务器的地址:
4. 注册
5. 开始游玩吧

### IP
<img src="//motd.smgoro.top/status_img?host=k2.getmc.cn:15132"></img >
请忽略上面的结果

IP:k2.getmc.cn

端口:15292
<hr>
创造服

<img src="//motd.smgoro.top/status_img?host=k1.getmc.cn:15452"></img >

地址：k1.getmc.cn

端口：15452
<hr>
互通服

<img src="//motd.smgoro.top/status_img?host=mcp7.rhymc.com:1141"></img >

mcp7.rhymc.com

端口:1141
<hr>